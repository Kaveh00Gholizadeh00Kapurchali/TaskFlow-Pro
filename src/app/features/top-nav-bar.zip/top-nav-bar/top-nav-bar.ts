import { Component, input, output, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import {MatButtonModule} from '@angular/material/button';
import {MatToolbarModule} from '@angular/material/toolbar';

@Component({
  imports: [RouterLink, MatToolbarModule, MatButtonModule],
  selector: 'app-top-nav-bar',
  styleUrl: './top-nav-bar.css',
  templateUrl: './top-nav-bar.html',
})
export class TopNavBar {
  // urls 
  homeURL : string = 'http://localhost:4200/';
  createNewTaskURL :string = '' ;
  taskManagementURL : string = '';



  currentTime = signal(new Date())

  clock = [{
    country : 'Iran',
    timeZone : 'Asia/Tehran'
  }];





  FormatTime(zone: string){
    return this.currentTime().toLocaleTimeString('en-US', {
      timeZone: zone,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    })
  }
  FormatDate(zone: string){
    return this.currentTime().toLocaleDateString('en-US', {
      timeZone: zone,
      weekday: 'long',
      month: 'short',
      day: 'numeric'
    })
  }

}
